import React from 'react';
import './app.sass';

const App = () => {
   return (
    <div >
     <p> React Modèle Work !</p>
    </div>
  );
};

export default App;
