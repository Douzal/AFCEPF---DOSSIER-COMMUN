package fr.afcepf.al32.td3;

public interface BonusFactory<T extends Unit, E extends Bonus<T>> {
	BonusFactory<T, E> addFireBonus(int value);
	BonusFactory<T, E> addHealthBonus(int value);
	BonusFactory<T, E> addSpeedBonus(int value);
	BonusFactory<T, E> setGlobalMultiplier(int value);
	
	E create();
}
