package fr.afcepf.al32.decorator;

public abstract class ClientAvecReduction extends Client{
	
	protected Client client;

	public ClientAvecReduction(Client client) {
		super();
		this.client = client;
	}
	
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return client.getNom();
	}
	
	

}
