package fr.afcepf.al32.composite;

public class Personne implements Destinataire{
	private String nom;

	@Override
	public void envoyer(String msg) {
		System.out.println(nom + " re�oit ["+msg+']');
	}
	
	public Personne(String nom) {
		this.nom = nom;
	}
	
}
