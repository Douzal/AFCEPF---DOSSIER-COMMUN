package fr.afcepf.al32.td3;

public interface TransportableUnit extends Unit{
}
