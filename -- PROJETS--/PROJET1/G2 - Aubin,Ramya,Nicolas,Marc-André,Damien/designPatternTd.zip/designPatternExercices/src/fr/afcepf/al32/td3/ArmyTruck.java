/*
 * Created on 29 oct. 2005
 *
 */
package fr.afcepf.al32.td3;

import fr.afcepf.al32.td3.BaseHuman.HumanType;

/** 
 * @author Thibault
 * @author R�mi
 */
public class ArmyTruck extends TransportUnit{


	@Override
	public HumanType getCorps() {
		// TODO Auto-generated method stub
		return HumanType.Soldier;
	}
}
