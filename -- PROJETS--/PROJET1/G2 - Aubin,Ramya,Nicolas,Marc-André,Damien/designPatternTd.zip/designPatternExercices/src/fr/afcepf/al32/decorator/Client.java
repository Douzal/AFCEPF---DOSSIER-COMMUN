package fr.afcepf.al32.decorator;

public abstract class Client {

	protected String nom;
	
	protected int coutBillet;
	
	public abstract String getNom();

	public abstract int getCoutBillet();
	
	public String getIntitule() {
		return "billet";
	}

	public Client(String nom, int coutBillet) {
		super();
		this.nom = nom;
		this.coutBillet = coutBillet;
	}

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
