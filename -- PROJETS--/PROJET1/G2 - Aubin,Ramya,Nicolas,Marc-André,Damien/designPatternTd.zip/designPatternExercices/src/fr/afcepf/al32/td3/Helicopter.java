/**
 * 27 oct. 2005
 * tpGenieLog
 * Thibault
 */
package fr.afcepf.al32.td3;

import fr.afcepf.al32.td3.BaseHuman.HumanType;

/** 
 * @author Thibault
 * @author R�mi
 */
public class Helicopter extends TransportUnit{

	@Override
	public HumanType getCorps() {
		// TODO Auto-generated method stub
		return HumanType.Aviator;
	}
}
