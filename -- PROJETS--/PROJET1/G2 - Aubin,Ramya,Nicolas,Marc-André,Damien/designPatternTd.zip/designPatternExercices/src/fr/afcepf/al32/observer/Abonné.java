package fr.afcepf.al32.observer;

public interface Abonné {
	void update(int ca, int vente);
}
