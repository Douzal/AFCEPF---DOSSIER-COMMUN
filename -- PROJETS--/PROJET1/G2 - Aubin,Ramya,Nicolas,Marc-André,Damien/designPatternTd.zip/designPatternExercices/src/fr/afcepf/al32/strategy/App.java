package fr.afcepf.al32.strategy;

public class App {

	public static void main(String[] args) {
		Canard canard = new CanardColVert();
		
		canard.affiche();
		canard.performVol();
		canard.performCoin();

	}

}
