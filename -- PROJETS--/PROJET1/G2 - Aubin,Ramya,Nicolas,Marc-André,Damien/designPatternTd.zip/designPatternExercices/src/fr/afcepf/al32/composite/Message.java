package fr.afcepf.al32.composite;
import java.util.ArrayList;
import java.util.List;

public class Message {
	private String contenu;
	
	private List<Destinataire> destinataires = new ArrayList<Destinataire>();
	
	public Message(String msg) {
		this.contenu = msg;
	}

	
	public List<Destinataire> getDestinataires() {
		return destinataires;
	}


	public void addDestinataire(Destinataire destinataire) {
		destinataires.add(destinataire);
	}
	
	public void envoyer() {
		for (Destinataire destinataire : destinataires) {
			destinataire.envoyer(contenu);
		}
	}
}
