package fr.afcepf.al32.strategy;

public class CanardMarais extends Canard {

	@Override
	public void affiche() {
		System.out.println("creation d'un canard des marais");
		
	}

}
