package fr.afcepf.al32.td3;

import fr.afcepf.al32.td3.BaseHuman.HumanType;

public class HumanWithBonus implements Human, Bonus<Human>{

	private int speedModifier;
	
	private int healthModifier;
	
	private int fireModifier;
	
	private int globalMultiplier;
	
	protected Human human;
	
	@Override
	public HumanType type() {
		return human.type();
	}

	public HumanWithBonus(Human human, int speedModifier, int healthModifier, int fireModifier, int globalMultiplier) {
		super();
		this.human = human;
		this.speedModifier = speedModifier;
		this.healthModifier = healthModifier;
		this.fireModifier = fireModifier;
		this.globalMultiplier = globalMultiplier;
	}
	
	@Override
	public int speed() {
		// TODO Auto-generated method stub
		return (human.speed()+speedModifier)*globalMultiplier;
	}

	@Override
	public int health() {
		// TODO Auto-generated method stub
		return (human.health()+healthModifier)*globalMultiplier;
	}

	@Override
	public int fire() {
		// TODO Auto-generated method stub
		return (human.fire()+fireModifier)*globalMultiplier;
	}
}
