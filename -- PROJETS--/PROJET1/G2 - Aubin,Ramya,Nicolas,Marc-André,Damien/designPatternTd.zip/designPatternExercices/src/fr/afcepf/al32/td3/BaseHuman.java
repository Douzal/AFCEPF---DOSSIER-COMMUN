/**
 * 27 oct. 2005
 * tpGenieLog
 * Thibault
 */
package fr.afcepf.al32.td3;

/**
 * @author Thibault
 * @author R�mi
 *
 */
public class BaseHuman implements Human{
  public enum HumanType{
    Soldier(30,1,15), 
    Medic(-5,2,10),
    Marine(10,3,20),
    Aviator(10,3,20),
    GrenadeLauncher(-5,2,15),
    FlameThrower(20,2,15);
    
    private HumanType(int fire,int speed, int health){
      this.fire = fire;
      this.speed = speed;
      this.health = health;
    }
    
    final int fire;
    final int speed;
    final int health;
  }
  
  public BaseHuman(HumanType type){
    this.type=type;
    this.fire=type.fire;
    this.speed=type.speed;
    this.health=type.health;
  }
  
  @Override
  public int speed() {
    return speed;
  }
  
  @Override
  public int health() {
    return health;
  }
  
  @Override
  public int fire() {
    return fire;
  }
  
  @Override
  public HumanType type() {
    return type;
  }
  
  private final HumanType type;
  private final int fire;
  private final int speed;
  private final int health;

}
