package fr.afcepf.al32.composite;

public abstract interface Destinataire {
	void envoyer(String msg);
}
