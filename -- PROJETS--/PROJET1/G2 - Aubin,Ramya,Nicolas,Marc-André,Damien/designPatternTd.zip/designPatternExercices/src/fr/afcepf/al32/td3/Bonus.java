package fr.afcepf.al32.td3;

public interface Bonus<E> {

}
