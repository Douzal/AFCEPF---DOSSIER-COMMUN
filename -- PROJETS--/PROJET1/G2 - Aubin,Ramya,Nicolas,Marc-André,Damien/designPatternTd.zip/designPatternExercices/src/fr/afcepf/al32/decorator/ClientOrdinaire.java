package fr.afcepf.al32.decorator;

public class ClientOrdinaire extends Client{

	public ClientOrdinaire(String nom, int coutBillet) {
		super(nom, coutBillet);
	}

	@Override
	public int getCoutBillet() {
		// TODO Auto-generated method stub
		return coutBillet;
	}

	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return nom;
	}

	public ClientOrdinaire() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
