package fr.afcepf.al32.decorator;

public class App {

	public static void main(String[] args) {
		Client c = new AvecCarte(new AvecJeune(new ClientOrdinaire("martin", 200)));
		
		System.out.println(String.format("%s a acheté un %s pour le prix de %d", c.getNom(), c.getIntitule(), c.getCoutBillet()));

	}

}
