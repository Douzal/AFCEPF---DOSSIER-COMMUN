package fr.afcepf.al32.iterator;

public class App {

	public static void main(String[] args) {
		Boissons b = new Boissons();
		
		for(String boisson : b) {
			System.out.println(boisson);
		}

	}

}
