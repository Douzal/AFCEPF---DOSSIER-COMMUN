package fr.afcepf.al32.iterator;

import java.util.Iterator;

public class Boissons implements Iterable<String>{

	String[] boissons = {"thé", "café", "bière"};

	@Override
	public Iterator<String> iterator() {
		return new IteratorSurBoisson(this);
	}
	
	private class IteratorSurBoisson implements Iterator<String>{
		
		private Boissons boissons;
		
		private int compteur = 0;
		
		public IteratorSurBoisson(Boissons boissons) {
			super();
			this.boissons = boissons;
		}

		@Override
		public boolean hasNext() {
			return compteur < boissons.boissons.length;
		}

		@Override
		public String next() {
			String next = boissons.boissons[compteur++];
			return next;
		}
		
	}
}
