package fr.afcepf.al32.td3;

public interface Unit {
	int speed();
	
	int health();

	int fire();
}
