package fr.afcepf.al32.strategy;

public class VolAile implements FaconDeVoler{

	@Override
	public void vol() {
		System.out.println("vol avec ailes");
		
	}

}
