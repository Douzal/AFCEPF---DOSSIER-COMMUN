package fr.afcepf.al32.decorator;

public class AvecCarte extends ClientAvecReduction{

	public AvecCarte(Client client) {
		super(client);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCoutBillet() {
		// TODO Auto-generated method stub
		return client.getCoutBillet()-30;
	}

}
