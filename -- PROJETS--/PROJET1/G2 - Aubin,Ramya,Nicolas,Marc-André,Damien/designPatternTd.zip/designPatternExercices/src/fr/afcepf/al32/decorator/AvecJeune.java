package fr.afcepf.al32.decorator;

public class AvecJeune extends ClientAvecReduction{

	public AvecJeune(Client client) {
		super(client);
	}

	@Override
	public int getCoutBillet() {
		// TODO Auto-generated method stub
		return client.getCoutBillet()-20;
	}

}
