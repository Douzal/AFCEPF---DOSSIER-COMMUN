/**
 * 27 oct. 2005
 * tpGenieLog
 * Thibault
 */
package fr.afcepf.al32.td3;

/** 
 * @author Thibault
 * @author R�mi
 */
public class FighterPlane implements TransportableUnit{

	@Override
	public int speed() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int health() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int fire() {
		// TODO Auto-generated method stub
		return 0;
	}

}
