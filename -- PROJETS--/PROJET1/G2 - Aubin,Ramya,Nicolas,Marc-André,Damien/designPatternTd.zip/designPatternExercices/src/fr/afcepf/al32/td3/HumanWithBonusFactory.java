package fr.afcepf.al32.td3;

public class HumanWithBonusFactory implements BonusFactory<Human, HumanWithBonus> {
	
	private int speedModifier;
	
	private int healthModifier;
	
	private int fireModifier;
	
	private int globalMultiplier=1;
	
	private Human human;
	
	private HumanWithBonusFactory(Human target) {
		this.human = target;
	}
	
	public static HumanWithBonusFactory createBonusFor(Human target) {
		return new HumanWithBonusFactory(target);
	}

	@Override
	public BonusFactory<Human, HumanWithBonus> addFireBonus(int value) {
		fireModifier+=value;
		return this;
	}

	@Override
	public BonusFactory<Human, HumanWithBonus> addHealthBonus(int value) {
		healthModifier+=value;
		return this;
	}

	@Override
	public BonusFactory<Human, HumanWithBonus> addSpeedBonus(int value) {
		speedModifier+=value;
		return this;
	}

	@Override
	public BonusFactory<Human, HumanWithBonus> setGlobalMultiplier(int value) {
		globalMultiplier = value;
		return this;
	}

	@Override
	public HumanWithBonus create() {
		HumanWithBonus result = new HumanWithBonus(human, speedModifier, healthModifier, fireModifier, globalMultiplier);
		resetValue();
		return result;
	}

	private void resetValue() {
		speedModifier =0;
		healthModifier =0;
		fireModifier=0;
		globalMultiplier=1;
		
	}
	
}
