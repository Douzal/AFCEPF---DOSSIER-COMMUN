package fr.afcepf.al32.observer;

public interface Editeur {
	void ajouteAbonné(Abonné abonné);
	void supprimeAbonné(Abonné abonné);
	void notifierAbonnés();
}
