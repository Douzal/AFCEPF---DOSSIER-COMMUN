package fr.afcepf.al32.td3;

import fr.afcepf.al32.td3.BaseHuman.HumanType;

public interface Human extends TransportableUnit{
	 HumanType type();
}
