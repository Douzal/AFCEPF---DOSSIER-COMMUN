package fr.afcepf.al32.td3;

import java.util.ArrayList;
import java.util.List;

import fr.afcepf.al32.td3.BaseHuman.HumanType;

public abstract class TransportUnit implements Unit {

	private List<TransportableUnit> passengers = new ArrayList<>();

	public void addPassenger(TransportableUnit passenger) {
		passengers.add(passenger);
	}

	public void removePassenger(TransportableUnit passenger) {
		passengers.remove(passenger);
	}

	public void viewPassengers() {
		for (TransportableUnit soloUnit : passengers) {
			System.out.println(soloUnit.getClass().getSimpleName());
		}
	}

	@Override
	public int speed() {
		int res = 0;

		for (TransportableUnit unit : passengers) {
			if (unit instanceof Human) {
				Human human = (Human) unit;
				if (human.type().equals(getCorps())) {
					res += human.speed();
				}
			}
		}
		return res;
	}

	@Override
	public int health() {
		int res = 0;

		for (TransportableUnit unit : passengers) {
			if (unit instanceof Human) {
				Human human = (Human) unit;
				if (human.type().equals(getCorps())) {
					res += human.health();
				}
			}
		}
		return res;
	}

	@Override
	public int fire() {
		int res = 0;

		for (TransportableUnit unit : passengers) {
			if (unit instanceof Human) {
				Human human = (Human) unit;
				if (human.type().equals(getCorps())) {
					res += human.fire();
				}
			}
		}
		return res;
	}
	
	public abstract HumanType getCorps();
}
