package fr.afcepf.al32.strategy;

public abstract class Canard {
	protected FaconDeVoler comportementDeVol;
	
	protected FaconDeCoinner comportementDeCoin;
	
	public void performVol() {
		comportementDeVol.vol();
	}
	
	public void performCoin() {
		comportementDeCoin.coin();
	}
	
	public abstract void affiche();
}
