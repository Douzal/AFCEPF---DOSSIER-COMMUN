package fr.afcepf.al32.td3;

import fr.afcepf.al32.td3.BaseHuman.HumanType;

public class App {

	public static void main(String[] args) {
		TransportUnit destroyer = new Destroyer();
		
		TransportUnit truck = new ArmyTruck();
		
		HumanWithBonusFactory factory = HumanWithBonusFactory.createBonusFor(new BaseHuman(HumanType.Soldier));
		
		HumanWithBonus withSpeedAndHealthBonusSoldier = factory.addSpeedBonus(20).addHealthBonus(10).create();
		
		HumanWithBonus withDoubleMultiplicatorBonusSoldier = HumanWithBonusFactory.createBonusFor(new BaseHuman(HumanType.Soldier)).setGlobalMultiplier(2).create();
		
		HumanWithBonus withFireBonusMarine = HumanWithBonusFactory.createBonusFor(new BaseHuman(HumanType.Marine)).addFireBonus(23).create();
		
		HumanWithBonus withFireAndSpeedBonusMarine = HumanWithBonusFactory.createBonusFor(withFireBonusMarine).addSpeedBonus(20).create();
		
		destroyer.addPassenger(withDoubleMultiplicatorBonusSoldier);
		destroyer.addPassenger(withFireBonusMarine);
		destroyer.addPassenger(withFireAndSpeedBonusMarine);
		
		truck.addPassenger(withDoubleMultiplicatorBonusSoldier);
		truck.addPassenger(withSpeedAndHealthBonusSoldier);
		truck.addPassenger(withFireBonusMarine);
		
		System.out.println(String.format("Destroyer: Speed: %d, Health: %d, Fire: %d", destroyer.speed(), destroyer.health(), destroyer.fire()));
		
		System.out.println(String.format("Truck: Speed: %d, Health: %d, Fire: %d", truck.speed(), truck.health(), truck.fire()));
	}
}
