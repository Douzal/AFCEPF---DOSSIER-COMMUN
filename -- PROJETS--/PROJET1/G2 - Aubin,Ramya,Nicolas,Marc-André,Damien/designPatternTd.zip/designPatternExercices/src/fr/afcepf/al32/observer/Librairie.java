package fr.afcepf.al32.observer;

import java.util.ArrayList;
import java.util.List;

public class Librairie implements Editeur{
	
	private int ca;
	
	private int nbVol;
	
	private int nbVisiteur;
	
	private List<Abonné> abonnés = new ArrayList<>();

	@Override
	public void ajouteAbonné(Abonné abonné) {
		abonnés.add(abonné);
		
	}

	@Override
	public void supprimeAbonné(Abonné abonné) {
		abonnés.remove(abonné);
		
	}

	@Override
	public void notifierAbonnés() {
		for (Abonné abonné : abonnés) {
			abonné.update(ca, nbVol);
		}
		
	}
	
	public void dataChanged() {
		setChanged(10000, 50, 20);
		notifierAbonnés();
	}
	
	public void setChanged(int a, int b, int c){
		ca=a;
		nbVol=b;
		nbVisiteur=c;
	}

	public List<Abonné> getAbonnés() {
		return abonnés;
	}

	public void setAbonnés(List<Abonné> abonnés) {
		this.abonnés = abonnés;
	}

	
}
