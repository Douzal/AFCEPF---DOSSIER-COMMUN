package fr.afcepf.al32.strategy;

public interface FaconDeVoler {
	void vol();
}
