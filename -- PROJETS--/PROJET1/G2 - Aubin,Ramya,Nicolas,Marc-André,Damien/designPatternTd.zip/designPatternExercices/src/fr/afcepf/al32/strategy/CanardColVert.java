package fr.afcepf.al32.strategy;

public class CanardColVert extends Canard{

	public CanardColVert() {
		comportementDeVol = new VolAile();
		comportementDeCoin = new CoinAigu();
	}

	@Override
	public void affiche() {
		System.out.println("création d'un col vert");
		
	}
}
