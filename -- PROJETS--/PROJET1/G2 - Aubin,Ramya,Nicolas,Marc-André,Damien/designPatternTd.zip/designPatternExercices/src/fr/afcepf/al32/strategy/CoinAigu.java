package fr.afcepf.al32.strategy;

public class CoinAigu implements FaconDeCoinner{

	@Override
	public void coin() {
		System.out.println("coin aigu");
		
	}

}
