package fr.afcepf.al32.strategy;

public interface FaconDeCoinner {
	void coin();
}
