
INSERT INTO Personne(typePersonne,id,prenom,nom,email) VALUES('Association',1,'olie','Condor','olie.condor@gmail.com');
INSERT INTO Personne(typePersonne,id,prenom,nom,email) VALUES('Association',2,'alain','Therieur','at@gmail.com');
INSERT INTO Personne(typePersonne,id,prenom,nom,email) VALUES('Administrateur',3,'jean','Bon','jb@gmail.com');
INSERT INTO Personne(typePersonne,id,prenom,nom,email) VALUES('Donateur',4,'jean','Phil','jp@gmail.com');
