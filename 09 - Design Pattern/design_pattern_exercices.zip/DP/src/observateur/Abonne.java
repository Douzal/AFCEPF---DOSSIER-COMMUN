package observateur;

public interface Abonne {
	void upDate(int ca, int vente);
}
