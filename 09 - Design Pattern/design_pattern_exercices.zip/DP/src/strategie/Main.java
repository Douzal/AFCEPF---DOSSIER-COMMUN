package strategie;

public class Main {
	public static void main(String[] args) {
		CanardMarais cv = new CanardMarais();
		cv.coiner();
		cv.voler();
	}
}
