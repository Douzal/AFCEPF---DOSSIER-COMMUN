package strategie;

public class VolAvecAiles implements ComportementDeVol{

	@Override
	public void vol() {
		System.out.println(" vol haut");
		
	}

}
