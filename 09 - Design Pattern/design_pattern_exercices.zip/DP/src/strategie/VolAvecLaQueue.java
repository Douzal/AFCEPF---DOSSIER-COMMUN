package strategie;

public class VolAvecLaQueue implements ComportementDeVol{

	@Override
	public void vol() {
		// TODO Auto-generated method stub
		
	}

}
