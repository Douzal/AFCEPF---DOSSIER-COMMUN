package strategie;

public interface ComportementDeCoincoin {
	void coincoin();
}
