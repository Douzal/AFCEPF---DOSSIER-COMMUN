package strategie;

public interface ComportementDeVol {
	void vol();
}
