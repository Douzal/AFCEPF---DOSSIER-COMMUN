package strategie;

public class CouineBeaucoup implements ComportementDeCoincoin{

	@Override
	public void coincoin() {
		System.out.println( "couine beaucoup  et fort");
		
	}

}
