package strategie;

public class CanardColVert {

}
