package decoEtCompositSolution;

import decoEtCompositSolution.Human.HumanType;

public class AircraftCarrier extends Transporteur {
	
	
	
	public AircraftCarrier() {
		typeDeCorpsActif = HumanType.Marine;
	}
	@Override
	public String  affiche() {
		String s = " AircraftCarrier transporte -->";
		for( Transportable each : getLesTransportables())
			  s += each.affiche();
		return s;
	}


}
