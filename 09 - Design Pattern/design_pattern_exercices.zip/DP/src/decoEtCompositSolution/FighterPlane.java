
package decoEtCompositSolution;


public class FighterPlane  implements Transportable{
  public int speed() {
     return 0;
   }
   
   public int health() {
     return 0;
   }
   
   public int fire() {
     return 0;
   }

   @Override
   public String affiche() {
		return " FlighterPlane ";
   }
}
