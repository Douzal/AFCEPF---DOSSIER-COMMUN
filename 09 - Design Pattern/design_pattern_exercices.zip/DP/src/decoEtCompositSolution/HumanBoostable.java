package decoEtCompositSolution;

public abstract class HumanBoostable implements Transportable{

}
