package decoEtCompositSolution;

public interface Transportable extends Unite{

}
