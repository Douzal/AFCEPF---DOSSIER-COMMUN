package decoEtCompositSolution;

import java.util.ArrayList;
import java.util.List;

import decoEtCompositSolution.Human.HumanType;

public abstract class Transporteur implements  Unite {
	
	protected HumanType typeDeCorpsActif;
	
	private List<Transportable> lesTransportables = new ArrayList<Transportable>();
	
	public void ajouteTransportable(Transportable transportable ) {
		lesTransportables.add(transportable);
	}
	
	public void supprimeTransportable(Transportable transportable ) {
		lesTransportables.remove(transportable);
	}

	public List<Transportable> getLesTransportables() {
		return lesTransportables;
	}

	public void setLesTransportables(List<Transportable> lesTransportables) {
		this.lesTransportables = lesTransportables;
	}
	
	public int speed() {
		int s = 0;
		for( Transportable tr : getLesTransportables()) {
		      if( tr instanceof Human){
		    	  Human human =(Human) tr;
		    	  if ( human.type() == typeDeCorpsActif)
		    		  s += tr.speed();
		      }
		}
		return s;
   }
   
	public int health() {
		int s = 0;
		for( Transportable tr : getLesTransportables()) {
		      if( tr instanceof Human){
		    	  Human human =(Human) tr;
		    	  if ( human.type() == typeDeCorpsActif)
		    		  s += tr.health();
		      }
		}
		return s;
   }
	
	public int fire() {
		int s = 0;
		for( Transportable tr : getLesTransportables()) {
		      if( tr instanceof Human){
		    	  Human human =(Human) tr;
		    	  if ( human.type() == typeDeCorpsActif)
		    		  s += tr.fire();
		      }
		}
		return s;
   }
}
