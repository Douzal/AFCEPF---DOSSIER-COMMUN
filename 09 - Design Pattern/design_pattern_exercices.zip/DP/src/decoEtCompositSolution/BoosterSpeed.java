package decoEtCompositSolution;

public class BoosterSpeed extends Booster{

	HumanBoostable humanBoostable;
	int valeurDuBoost = 0;
	
	public BoosterSpeed(HumanBoostable humanBoostable, int valeurDuBoost) {
		super();
		this.humanBoostable = humanBoostable;
		this.valeurDuBoost = valeurDuBoost;
	}
	
	public int speed() {
		return humanBoostable.speed() + valeurDuBoost;
	}

	@Override
	public String affiche() {
		return humanBoostable.affiche() + " avec booster de speed de " + valeurDuBoost;
		
	}

	@Override
	public int health() {
		// TODO Auto-generated method stub
		return 	 humanBoostable.health();
	}

	@Override
	public int fire() {
		// TODO Auto-generated method stub
		return humanBoostable.fire();
	}
	
}
