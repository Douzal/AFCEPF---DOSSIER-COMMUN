
package decoEtCompositSolution;

import decoEtCompositSolution.Human.HumanType;

public class ArmyTruck extends Transporteur {
	
	
	public ArmyTruck() {
		typeDeCorpsActif = HumanType.Soldier;
	}
	@Override
	public String affiche() {
		String s = " ArmyTruck transporte -->";
		for( Transportable each : getLesTransportables())
				s +=	each.affiche();
		return s;
	 }

}
