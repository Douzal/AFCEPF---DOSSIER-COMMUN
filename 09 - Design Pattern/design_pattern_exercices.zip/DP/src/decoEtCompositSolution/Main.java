package decoEtCompositSolution;

import decoEtCompositSolution.Human.HumanType;

public class Main {
	public static void main(String[] args) {
		HumanBoostable h1 = new Human(HumanType.Soldier);
		HumanBoostable h1bis = new Human(HumanType.Soldier);
		
		HumanBoostable h2 = new BoosterSpeed( new BoosterFire( new Human(HumanType.Aviator),2),2);
		
		HumanBoostable h3 = new BoosterFire(new Human(HumanType.Marine), 12);
			
		ArmyTruck armyTruck1 = new ArmyTruck();
		armyTruck1.ajouteTransportable(h1);
		armyTruck1.ajouteTransportable(h1bis);
		armyTruck1.ajouteTransportable(h2);
		armyTruck1.ajouteTransportable(h3);
		
		Destroyer destroyer1 = new Destroyer();
		destroyer1.ajouteTransportable(h1);
		destroyer1.ajouteTransportable(h3);
	
	// pour version 1
	// destroyer1.ajouteTransportable(armyTruck1); 
		
		armyTruck1.affiche();
		destroyer1.affiche();
		System.out.println(armyTruck1.speed());
	}
}
