
package decoEtCompositSolution;

import decoEtCompositSolution.Human.HumanType;

public class Helicopter  extends Transporteur {
	
	
	public Helicopter() {
		typeDeCorpsActif = HumanType.Aviator;
	}


   @Override
   public String  affiche() {
	   String s = (" hélicopter transporte -->");
	   for( Transportable each : getLesTransportables())
		   s += each.affiche();
	   return s;
   }
}
