package decoEtCompositSolution;

public abstract class Booster extends HumanBoostable{
}
