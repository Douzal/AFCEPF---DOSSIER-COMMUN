package decoEtCompositSolution;

public class BoosterHealth extends Booster{

	HumanBoostable humanBoostable;
	int valeurDuBoost = 0;
	
	public BoosterHealth(HumanBoostable humanBoostable, int valeurDuBoost) {
		super();
		this.humanBoostable = humanBoostable;
		this.valeurDuBoost = valeurDuBoost;
	}
	
	public int health() {
		return humanBoostable.health() + valeurDuBoost;
	}

	@Override
	public String affiche() {
		return humanBoostable.affiche() + " booster de health de " + valeurDuBoost;
		
	}

	@Override
	public int speed() {
		return humanBoostable.health();
	}

	@Override
	public int fire() {
		return humanBoostable.fire();
	}
	
	
	

}
