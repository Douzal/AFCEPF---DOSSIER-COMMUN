package decoEtCompositSolution;

public interface Unite {
	public String affiche();
	public int speed();
	public int health();
	  
	public int fire();
}
