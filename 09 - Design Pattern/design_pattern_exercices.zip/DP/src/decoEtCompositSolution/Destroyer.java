
package decoEtCompositSolution;

import decoEtCompositSolution.Human.HumanType;

public class Destroyer extends Transporteur{
	
	
	
	 public Destroyer() {
		typeDeCorpsActif = HumanType.Marine;
	}

	@Override
	 public String  affiche() {
		 String s = " Destroyer transporte -->";
		 for( Transportable each : getLesTransportables())
			    s += each.affiche();
		 return s;
	  }
	 
 
}
