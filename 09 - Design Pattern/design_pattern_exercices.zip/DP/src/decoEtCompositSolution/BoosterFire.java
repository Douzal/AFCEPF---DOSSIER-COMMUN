package decoEtCompositSolution;

public class BoosterFire  extends Booster{

	HumanBoostable humanBoostable;
	int valeurDuBoost = 0;
	
	public BoosterFire(HumanBoostable humanBoostable, int valeurDuBoost) {
		super();
		this.humanBoostable = humanBoostable;
		this.valeurDuBoost = valeurDuBoost;
	}
	
	public int fire() {
		return humanBoostable.fire() + valeurDuBoost;
	}

	@Override
	public String affiche() {
		return  humanBoostable.affiche() + " avec booster fire de " + valeurDuBoost;
	}

	@Override
	public int speed() {
		 return humanBoostable.speed();
	}

	@Override
	public int health() {
		// TODO Auto-generated method stub
		 return humanBoostable.health();
	}
	
	
	
}
