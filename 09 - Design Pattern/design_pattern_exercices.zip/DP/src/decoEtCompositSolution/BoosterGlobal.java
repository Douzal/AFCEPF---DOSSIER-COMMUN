package decoEtCompositSolution;

public class BoosterGlobal extends Booster{

	HumanBoostable humanBoostable;
	int valeurDuBoost = 0;
	
	public BoosterGlobal(HumanBoostable humanBoostable, int valeurDuBoost) {
		super();
		this.humanBoostable = humanBoostable;
		this.valeurDuBoost = valeurDuBoost;
	}
	
	public int fire() {
		return humanBoostable.fire() * valeurDuBoost;
	}
	public int speed() {
		return humanBoostable.speed() * valeurDuBoost;
	}
	public int health() {
		return humanBoostable.health() * valeurDuBoost;
	}

	@Override
	public String affiche() {
		return humanBoostable.affiche() + "avec booster global de " + valeurDuBoost;
		
	}

}
