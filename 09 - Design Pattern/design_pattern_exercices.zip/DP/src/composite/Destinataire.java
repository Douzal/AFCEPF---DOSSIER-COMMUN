package composite;

public abstract class Destinataire {
	public abstract void envoyer(String message);
}
