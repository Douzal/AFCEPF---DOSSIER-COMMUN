/**
 * 27 oct. 2005
 * tpGenieLog
 * Thibault
 */
package fr.umlv.gl.td2.war;

/** 
 * @author Thibault
 * @author R�mi
 */
public class FighterPlane {
  public int speed() {
    // TODO Auto-generated method stub
     return 0;
   }
   
   public int health() {
     // TODO Auto-generated method stub
     return 0;
   }
   
   public int fire() {
     // TODO Auto-generated method stub
     return 0;
   }
}
