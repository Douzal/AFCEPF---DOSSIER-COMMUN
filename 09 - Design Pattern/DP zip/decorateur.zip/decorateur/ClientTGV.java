package decorateur;

public class ClientTGV extends Client{

	@Override
	public int getCoutBillet() {
		
		return 200;
	}

}
