package decorateur;

public abstract class ClientAvecReductions extends Client{

	public abstract String getIntitulé();
	public abstract String getNom();
	
}
