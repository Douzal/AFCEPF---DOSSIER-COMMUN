﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleVisiteurDP
{
    class Program
    {
        static void Main(string[] args)
        {
            Entreprise entreprise = new Entreprise();

            AugmentationSalaire augmentationSalaire = new AugmentationSalaire();

            JourSupplementaireDeVacance jourSupplementaireDeVacance = new JourSupplementaireDeVacance();

            SalarierInterne collaborateur1 = new SalarierInterne("Jean", 1000.0, 10);
            SalarierInterne collaborateur2 = new SalarierInterne("Paul", 2000.0, 15);

            entreprise.Attach(collaborateur1);
            entreprise.Attach(collaborateur2);

            entreprise.AfficherCollaborateur();

            entreprise.Accept(augmentationSalaire);
            entreprise.Accept(jourSupplementaireDeVacance);

            
            entreprise.AfficherCollaborateur();

            Console.Read();
        }
    }
}
