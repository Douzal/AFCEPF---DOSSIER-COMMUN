package fr.benoit.outils;

public interface ITelephone 
{
	
}
