package fr.benoit.outils;

import java.util.ArrayList;

public class RangeTelephone 
{
	private int capacite;
	private ArrayList<ITelephone> telephones;

	public RangeTelephone(int capacite) {
		telephones = new ArrayList<>();
		this.capacite = capacite;
	}
	
	public void ranger(ITelephone t)
	{
		telephones.add(t);
	}
	
	public ITelephone recuperer(int i)
	{
		return telephones.remove(i);
	}
}
