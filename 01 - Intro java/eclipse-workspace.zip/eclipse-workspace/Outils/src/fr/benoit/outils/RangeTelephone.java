package fr.benoit.outils;

public class RangeTelephone 
{

	public RangeTelephone(int capacite)
	{
		System.out.println("JE ne suis pas du tout le range t�l�phone que vous croyez");
	}
}
