package fr.afcepf.outils;

public class Calculatrice 
{
	public int additionner(int a, int b)
	{
		return a + b;
	}
	
	public int soustraire(int a, int b)
	{
		return a - b;
	}
}
