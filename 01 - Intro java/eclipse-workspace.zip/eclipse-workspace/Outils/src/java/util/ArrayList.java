package java.util;

public class ArrayList 
{
	public ArrayList()
	{
		System.out.println("hahaha");
	}
}
