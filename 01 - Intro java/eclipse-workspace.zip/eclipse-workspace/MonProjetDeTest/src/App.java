import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.afcepf.outils.Calculatrice;
import fr.benoit.outils.RangeTelephone;

public class App {

	public static void main(String[] args) 
	{
		Logger l = LogManager.getLogger();
		l.error("Plop");

		int a = 39;
		int b = 3;

		ArrayList ar = new ArrayList();
		Calculatrice calc = new Calculatrice();
		
		int c = calc.additionner(a, b);
		
		RangeTelephone r = new RangeTelephone(42);
		
	}

}
