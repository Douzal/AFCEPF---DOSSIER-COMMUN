package fr.afcepf.heritage.vehicules;

public abstract class Vehicule 
{
	private int longueur;
	private int largeur;
	private String couleur;
		
	public int getLongueur() {
		return longueur;
	}

	@Override
	public String toString()
	{
		return "L : " + longueur + " - l : " + largeur + " - couleur : " + couleur;
	}

	public void setLongueur(int longueur) {
		this.longueur = longueur;
	}


	public int getLargeur() {
		return largeur;
	}


	public void setLargeur(int largeur) {
		this.largeur = largeur;
	}


	public String getCouleur() {
		return couleur;
	}


	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	
	public abstract boolean estTerrestre();

	public void avancer()
	{
		System.out.println("J'avance...");
	}
	
	
	public void tourner()
	{
		System.out.println("Je tourne...");
	}
}
