package fr.afcepf.heritage.simulateurVol;

import fr.afcepf.heritage.animaux.Oiseau;
import fr.afcepf.heritage.vehicules.Avion;

public interface IVolant 
{	
	public void voler();
	
	// BOUUHHHHHHHH !!!!!!
	/*
	public default String direPlop()
	{
		if (this.getClass() == Avion.class)
		{
			return "plop avion";
		}
		if (this.getClass() == Oiseau.class)
		{
			return "plop oiseau";
		}
		return "plop";
	}
	*/
	
	public int getVitesseCroisiere();
}
