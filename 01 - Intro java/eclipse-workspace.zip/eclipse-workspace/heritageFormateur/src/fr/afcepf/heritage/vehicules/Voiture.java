package fr.afcepf.heritage.vehicules;

public class Voiture extends Vehicule implements Cloneable
{
	private int puissance;
	private int cylindree;
	
	@Override
	public Voiture clone()
	{
		
		try {
			return (Voiture)super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public String toString()
	{
		// VOITURE - L : 500 - l : 200 - couleur : rouge - puiss : 350 - cyl : 4000
		return "VOITURE - " + super.toString() 
							+ " - puiss : " + puissance 
							+ " - cyl : " + cylindree;
	}
	
	@Override
	public boolean estTerrestre()
	{
		return true;
	}
	
	@Override
	public void avancer()
	{
		System.out.println("VROUUUUUMMMM !!!! ");
	}
	
	public int getPuissance() {
		return puissance;
	}

	public void setPuissance(int puissance) {
		this.puissance = puissance;
	}

	public int getCylindree() {
		return cylindree;
	}

	public void setCylindree(int cylindree) {
		this.cylindree = cylindree;
	}

	public void demarrer()
	{
		System.out.println("Je d�marre...");
	}
	
	public void arreter()
	{
		System.out.println("Je m'arr�te...");
	}	
}
