package fr.afcepf.heritage.vehicules;

public class Bateau extends Vehicule
{
	private int tirantEau;
	
	@Override
	public String toString()
	{
		return "BATEAU - " + super.toString() 
							+ " - tirant eau : " + tirantEau;
	}
	
	@Override
	public boolean estTerrestre() 
	{
		return false;
	}
	
	@Override
	public void avancer()
	{
		super.avancer();
		System.out.println("Ploooouuf !!!");
	}
	
	public int getTirantEau() {
		return tirantEau;
	}

	public void setTirantEau(int tirantEau) {
		this.tirantEau = tirantEau;
	}

	public void amarrer()
	{
		System.out.println("amarrage...");
	}
	
	public void couler()
	{
		System.out.println("glou glou...");
	}


}
