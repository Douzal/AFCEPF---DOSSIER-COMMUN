package fr.afcepf.heritage.vehicules;

import java.util.ArrayList;

public class App 
{

	public static void main(String[] args) 
	{
		Voiture v1 = new Voiture();
		Voiture v2 = v1.clone();
		
		v1.setCouleur("rouge");
		v1.setCylindree(4000);
		v1.setPuissance(350);
		v1.setLargeur(200);
		v1.setLongueur(500);
		
		//System.out.println(v1.hashCode());
		//System.out.println(v2.hashCode());
		
		// VOITURE - L : 500 - l : 200 - couleur : rouge - puiss : 350 - cyl : 4000
		System.out.println(v1);
		
		
		v1.equals(v2);
		String s = "hello";
		
		if(s.equals("hello"))
		{
			System.out.println("egal");
		}
		else
		{
			System.out.println("different");
		}
		
		// collection g�n�rique :
		ArrayList<Vehicule> mesVehicules = new ArrayList<>();
		
		mesVehicules.add(new Voiture());
		mesVehicules.add(new Bateau());
		mesVehicules.add(new Avion());
		
		for (int i = 0; i < mesVehicules.size(); i++)
		{
			Vehicule v = mesVehicules.get(i);
			v.avancer();
		}

		mesVehicules.forEach(v -> {v.avancer();System.out.println("youhou");});
		/*
		// tableau :
		int[] valeurs = new int[5];
		valeurs[0] = 75;
		valeurs[1] = 150;
		
		Vehicule[] maListe;
		 
		ArrayList ancienneListe = new ArrayList();
		
		ancienneListe.add(new Voiture());
		ancienneListe.add("Toto");
		ancienneListe.add(42);
		
		for(int i = 0; i < ancienneListe.size(); i++)
		{
			Voiture v = (Voiture)ancienneListe.get(i);
			v.demarrer();
		}
		*/
			
		/*	
			
		Vehicule veh = new Voiture();
		Voiture voi = new Voiture();
		Bateau bat = new Bateau();
		
		
		
		tester(bat);
		Vehicule v = new Bateau();
		v.avancer();
		*/
		//Voiture v2 = new Vehicule();
	}
	
	public static void tester(Vehicule v)
	{
		v.setCouleur("rouge");
		v.setLongueur(200);
		v.setLargeur(150);
		v.avancer();
		v.tourner();
	}
	
	
	
	
	
	

}



