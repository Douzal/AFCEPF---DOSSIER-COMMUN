package fr.afcepf.heritage.animaux;

import fr.afcepf.heritage.simulateurVol.IVolant;

public class Oiseau implements IVolant 
{

	@Override
	public void voler() {
		System.out.println("Flap flap");

	}

	@Override
	public int getVitesseCroisiere() {
		return 42;
	}

}
