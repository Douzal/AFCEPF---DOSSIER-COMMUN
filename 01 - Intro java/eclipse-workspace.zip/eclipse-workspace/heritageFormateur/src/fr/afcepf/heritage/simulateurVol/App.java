package fr.afcepf.heritage.simulateurVol;

import java.util.ArrayList;
import fr.afcepf.heritage.animaux.Oiseau;
import fr.afcepf.heritage.vehicules.Avion;

public class App {

	public static void main(String[] args) 
	{

		ArrayList<IVolant> objetsVolants = new ArrayList<>();

		objetsVolants.add(new Oiseau());
		objetsVolants.add(new Avion());
		
		// for each
		for(IVolant v : objetsVolants)
		{
			v.voler();
			//System.out.println(v.direPlop());
		}
		
		for (int i = 0; i < objetsVolants.size(); i++)
		{
			IVolant v = objetsVolants.get(i);
			v.voler();
		}
	}

}
