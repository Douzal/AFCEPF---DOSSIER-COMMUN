package fr.afcepf.heritage.vehicules;

import fr.afcepf.heritage.simulateurVol.IVolant;

public class Avion 
				extends Vehicule 
				implements IVolant
{		

	@Override
	public boolean estTerrestre() 
	{
		return true;
	}

	@Override
	public void voler() 
	{
		this.avancer();
	}

	@Override
	public int getVitesseCroisiere() 
	{
		return 842;
	}

}
