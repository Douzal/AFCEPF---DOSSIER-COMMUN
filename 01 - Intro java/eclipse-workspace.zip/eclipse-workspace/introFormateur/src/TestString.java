import java.util.Date;

public class TestString
{

	public static void main(String[] args)
	{
		version1(2000000);
		version2(1000000);
	}
	
	public static void version2(int nbOcc)
	{
		String s = "";
		
		Date debut = new Date();
		System.out.println("start : ");
		
		StringBuffer sb = new StringBuffer();
		
		for (int i = 0; i < nbOcc; i++)
		{
			sb.append("azertyuiopqsdfghjklmwxcvbn");
		}
		
		s = sb.toString();
		Date fin = new Date();

		long tempsEcoule = fin.getTime() - debut.getTime();
		System.out.println("ok : " + tempsEcoule);
	}
	
	public static void version1(int nbOcc)
	{
		String s = "";
		
		Date debut = new Date();
		System.out.println("start : ");
		
		for (int i = 0; i < nbOcc; i++)
		{
			s += "azertyuiopqsdfghjklmwxcvbn";
		}
		
		Date fin = new Date();

		long tempsEcoule = fin.getTime() - debut.getTime();
		System.out.println("ok : " + tempsEcoule);
	}

}
