package fr.afcepf.intro.banque;

import java.time.LocalDate;
import java.util.ArrayList;

import fr.afcepf.intro.Personne;
import fr.afcepf.intro.actifs.IActif;
import fr.afcepf.intro.banque.exceptions.BankOperationException;

public class CompteBancaire implements IActif
{
	private String numero;
	protected double solde;
	private LocalDate dateCreation;
	protected Personne titulaire;
	protected ArrayList<Operation> operations;
	//private ArrayList<Personne> mandataires;
	
	@Override
	public String toString() {
		return "Compte n�=" + numero + ", solde=" + solde + "� - Titulaire : " + this.titulaire;
	}

	public CompteBancaire(String numero, Personne titulaire)
	{
		this.operations = new ArrayList<>();
		this.titulaire = titulaire;
		this.titulaire.ajouterCompte(this);
		this.numero = numero;
		this.dateCreation = LocalDate.now();
		operations.add(new Operation(dateCreation, "Ouverture du compte", 0, TypeOperation.Ouverture));
	}
	
	public CompteBancaire(String numero, double soldeInitial, Personne titulaire)
	{
		this(numero, titulaire);
		if (soldeInitial > 0)
		{
			this.solde = soldeInitial;
		}
	}
	
	public String getNumero()
	{
		return numero;
	}
	
	public void setNumero(String numero)
	{
		this.numero = numero;
	}
	
	public double getSolde()
	{
		return solde;
	}
	
	public LocalDate getDateCreation()
	{
		return dateCreation;
	}
	
	private boolean estSoldeSuffisant(double montant)
	{
		solde -= 0.1;
		return (solde >= montant);		
	}
	
	public void crediter(double montant) throws BankOperationException
	{
		if (montant > 0)
		{
			solde += montant;
			operations.add(new Operation(LocalDate.now(), "Versement", montant, TypeOperation.Credit));
		}
		else
		{
			throw new BankOperationException("le montant doit �tre positif", "Cr�dit", montant);
		}
	}
	
	public void debiter(double montant) throws BankOperationException
	{
		if (montant > 0)
		{
			if (estSoldeSuffisant(montant))
			{
				solde -= montant;
				operations.add(new Operation(LocalDate.now(), "Retrait", montant, TypeOperation.Debit));
			}
			else
			{
				throw new BankOperationException("le solde est insufisant", "D�bit", montant);
			}
		}
		else 
		{
			throw new BankOperationException("le montant doit �tre positif", "D�bit", montant);
		}
	}
	
	public void virement(double montant, CompteBancaire destinataire) throws BankOperationException
	{
		try
		{
			this.debiter(montant);
			destinataire.crediter(montant);
		}
		catch(Exception exc)
		{
			throw new BankOperationException(exc.getMessage(), "Virement", montant);
		}
	}

	public double calculerMontantInterets()
	{
		return 0;
	}
	
	@Override
	public double getPrix() {
		
		return solde;
	}
	
	public void afficherJournal()
	{
		System.out.println("HISTORIQUE");
		for(Operation o : operations)
		{
			System.out.println(o);
		}
	}
}



