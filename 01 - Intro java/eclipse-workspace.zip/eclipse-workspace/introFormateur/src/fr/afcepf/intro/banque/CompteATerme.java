package fr.afcepf.intro.banque;

import fr.afcepf.intro.Personne;

public class CompteATerme extends CompteRemunere {
	
	private int duree;
	
	public CompteATerme(String numero, double tauxInteret, int duree, Personne titulaire) 
	{
		super(numero, tauxInteret, titulaire);
		this.duree = duree;
	}

	@Override
	public String toString() {
		return super.toString() + " duree=" + duree + " ans";
	}
	
	@Override
	public double calculerMontantInterets()
	{
		return super.calculerMontantInterets() * duree;
	}

}



