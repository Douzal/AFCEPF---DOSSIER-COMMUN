package fr.afcepf.intro.banque.exceptions;

public class BankOperationException extends Exception 
{
	private String typeOperation;
	private double montant;

	public BankOperationException(String message, String typeOperation, double montant)
	{
		super(message);
		this.typeOperation = typeOperation;
		this.montant = montant;
	}

	public String getTypeOperation() {
		return typeOperation;
	}

	public double getMontant() {
		return montant;
	}
	
	@Override
	public String getMessage()
	{
		return ("Erreur de " + this.typeOperation + " : \r\n\t" 
							+ super.getMessage() + "\r\n\t" 
							+ "montant demand� : " + this.montant );
	}
}




