package fr.afcepf.intro.banque;

import java.time.LocalDate;

public class Operation {

	private LocalDate date;
	private String libelle;
	private double montant;	
	private TypeOperation type;
	
	public Operation(LocalDate date, String libelle, double montant, TypeOperation type) 
	{
		this.date = date;
		this.libelle = libelle;
		this.montant = montant;
		this.type = type;
	}

	@Override
	public String toString() {
		return "Operation [date=" + date + ", libelle=" + libelle + ", montant=" + montant + ", type=" + type + "]";
	}
	
	

}
