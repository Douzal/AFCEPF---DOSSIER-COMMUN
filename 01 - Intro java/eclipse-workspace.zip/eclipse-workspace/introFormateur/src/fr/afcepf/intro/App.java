package fr.afcepf.intro;

import java.math.MathContext;

public class App
{

	public static void main(String[] args)
	{   
		System.out.println(Personne.AGE_MAJORITE);
		
		System.out.println(Personne.getNbInstances());
		
		Bidon b = Bidon.getInstance();
		b.test();
		
		Bidon b2 = Bidon.getInstance();
		b2.test();
		
		Bidon.FaireQqchose();
		double resultat = Math.cos(42);
		
		System.out.println(Math.PI);
		
		// affectation d'une valeur � ma variable :
		Personne p1 = new Personne("Noah", "Yannick", "1750132148648646");
		Personne p2 = new Personne();
		Personne p3 = new Personne("Federer", "Roger");
		Personne p4 = new Personne("Tsonga", 2);

		System.out.println(Personne.getNbInstances());
	
	}

}
