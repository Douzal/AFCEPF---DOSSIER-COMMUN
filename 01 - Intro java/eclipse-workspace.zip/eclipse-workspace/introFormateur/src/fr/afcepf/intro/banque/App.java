package fr.afcepf.intro.banque;

import java.io.FileNotFoundException;
import java.io.IOException;

import fr.afcepf.intro.Personne;
import fr.afcepf.intro.banque.exceptions.BankOperationException;

public class App
{

	public static void main(String[] args) throws BankOperationException 
	{
		Personne p1 = new Personne("yzokras","Nicolas");
		Personne p2 = new Personne("ifadahk", "Mouammar");
		
		CompteRemunere c1 = new CompteRemunere("12345", 0.05, p1);
		CompteBancaire c2 = new CompteBancaire("45678", p1);
		
		CompteATerme c3 = new CompteATerme("78945", 0.07, 5, p2);
		CompteBancaire c4 = new LivretA("AAAAAA", p2);
		
		System.out.println(c2);
		System.out.println(c3);
		
		c1.crediter(25000);
		c1.crediter(5000000);
		c1.debiter(500000);
		
		c1.afficherJournal();
	}
	
	
	

}
