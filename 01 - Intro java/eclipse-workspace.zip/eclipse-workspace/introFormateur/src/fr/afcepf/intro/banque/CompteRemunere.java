package fr.afcepf.intro.banque;

import fr.afcepf.intro.Personne;

public class CompteRemunere extends CompteBancaire
{
	private double tauxInteret;	
	
	public CompteRemunere(String numero, double tauxInteret, Personne titulaire)
	{
		super(numero, titulaire);
		this.tauxInteret = tauxInteret;
	}
	
	public double getTauxInteret() {
		return tauxInteret;
	}

	public void setTauxInteret(double tauxInteret) {
		this.tauxInteret = tauxInteret;
	}

	@Override
	public double calculerMontantInterets()
	{
		return tauxInteret * this.solde;	
	}

	@Override
	public double getPrix() 
	{
		return super.getPrix() + this.calculerMontantInterets();
	}
	
	@Override
	public String toString() {
		return super.toString() + "  tauxInteret=" + (tauxInteret * 100) + "%";
	}
	
	
}
