package fr.afcepf.intro.actifs;

public interface IActif 
{
	public double getPrix();

}
