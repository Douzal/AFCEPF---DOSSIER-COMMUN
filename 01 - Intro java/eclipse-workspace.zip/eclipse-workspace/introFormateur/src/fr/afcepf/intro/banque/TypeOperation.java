package fr.afcepf.intro.banque;

public enum TypeOperation 
{
	Ouverture,
	Debit,
	Credit,
	Virement,
	Cloture
}
