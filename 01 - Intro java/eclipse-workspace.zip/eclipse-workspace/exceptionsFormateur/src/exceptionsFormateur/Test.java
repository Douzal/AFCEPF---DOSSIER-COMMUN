package exceptionsFormateur;

import java.util.ArrayList;

public class Test {

	
	public static void main(String[] args) {

		afficherMemoire();
		ArrayList<String> liste = new ArrayList<>();
		liste.add("");
		
		for (int i =0; i < 1000; i++)
		{
			plop(liste);
		}
					
		System.out.println(liste.size());
		
		System.out.println("fin !");

	}

	public static void afficherMemoire()
	{
		System.out.print("free : " + Runtime.getRuntime().freeMemory());
		System.out.print(" - ");
		System.out.print(" total : " + Runtime.getRuntime().totalMemory());
		System.out.print(" - ");
		System.out.println(" used : " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
	}
	
	public static void plop(ArrayList<String> liste) {
	
		try
		{
			for(int i=1;i<10000000; i++)
			{
				liste.add(liste.get(i-1) + ",klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqh" + 
						"wsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl klqqjls flqjskl qsklf klqsjflkjqsklfj lklqqjls flqjskl qsklf klqsjflkjqsklfj l" +
						"kl jlkj ljl jkl jkljsdklfjsd fs dflks jdjizpisjv psd,vp isdwpvis dpvisjdpvisjdpvih oi odisj voou psdpvj^so dv^sodj v�js^dovj ppsidjv oisdjhvp is" +
						"kfplsd k�^sqk ckq vdfkljb mklqsdcs dbjnq,s ciosj v^qkscij sdmofblksiow vhpdfb pqsspod ivpsdi hmqsvjspodij" + 
						",klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqh" + 
						"wsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl klqqjls flqjskl qsklf klqsjflkjqsklfj lklqqjls flqjskl qsklf klqsjflkjqsklfj l" +
						"kl jlkj ljl jkl jkljsdklfjsd fs dflks jdjizpisjv psd,vp isdwpvis dpvisjdpvisjdpvih oi odisj voou psdpvj^so dv^sodj v�js^dovj ppsidjv oisdjhvp is" +
						"kfplsd k�^sqk ckq vdfkljb mklqsdcs dbjnq,s ciosj v^qkscij sdmofblksiow vhpdfb pqsspod ivpsdi hmqsvjspodij" + 
						",klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl ,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqhwsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl,klfjlqsjflkqjsklfjklqsjfkljqlfbjklqqjls flqjskl qsklf klqsjflkjqsklfj lqsjhfljhqslkfjklqws jflkqjhswklfhqklwshflkqh" + 
						"wsflkhqwslfhqlskwxjhflqshfklqsjhklfqsfjqsklfjklqsjfkl klqqjls flqjskl qsklf klqsjflkjqsklfj lklqqjls flqjskl qsklf klqsjflkjqsklfj l" +
						"kl jlkj ljl jkl jkljsdklfjsd fs dflks jdjizpisjv psd,vp isdwpvis dpvisjdpvisjdpvih oi odisj voou psdpvj^so dv^sodj v�js^dovj ppsidjv oisdjhvp is" +
						"kfplsd k�^sqk ckq vdfkljb mklqsdcs dbjnq,s ciosj v^qkscij sdmofblksiow vhpdfb pqsspod ivpsdi hmqsvjspodij");
			}
		}
		catch (OutOfMemoryError e)
		{
			afficherMemoire();
			System.out.println("ERREUR !!!");
		}
		finally
		{
			System.out.println("plop " + liste.size());
		}
		
		System.out.println("reprise");
	}
}
