package exceptionsFormateur;

import java.io.FileWriter;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class App {

	public static void main(String[] args)
	{
		//nimp();
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Saisissez un nombre : ");
		
		int x = 1;
		FileWriter fw = null;
		
		try
		{
			fw = new FileWriter("C:\\test\\toto.txt");
			fw.write("Salut toto !");
			int r = 0;
			int q = 42/r;
		}
		catch (IOException exc)
		{
			System.out.println("Erreur d'acc�s au fichier : " + exc.getMessage());
		}
		catch (Exception exc)
		{
			System.out.println("Erreur ind�termin�e : " + exc.getMessage());
		}
		finally
		{
			try 
			{
				if (fw != null)
				{
					fw.close();
				}
			} 
			catch (IOException e) 
			{			
				e.printStackTrace();
			}
		}	
		
		try
		{
			x = scan.nextInt();	
			int y = 42 / x;
			System.out.println(y);
			int[] tab = new int[2];
			tab[3] = y;
		}
		catch(InputMismatchException exc)
		{
			System.out.println("Erreur de saisie, x vaut 1");
		}
		catch (ArithmeticException exc)
		{
			System.out.println("Erreur : division par z�ro");
		}
		catch (Exception exc)
		{			
			System.out.println("Erreur : " + exc.getMessage());
			exc.printStackTrace(); 
		}

		System.out.println("termin� !");
	}
	
	public static void nimp()
	{
		nimp();
	}

}
