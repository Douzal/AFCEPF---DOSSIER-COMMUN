import fr.afcepf.intro.Personne;

public class TestMemoire
{

	public static void main(String[] args)
	{
		int a = 21;
		a = doubler(a);
		System.out.println(a);
		
		Personne v = new Personne();
		v.age = 32;
		doublerAge(v);
		System.out.println(v.age);
	}

	// Passage par valeur :
	public static int doubler(int x)
	{
		return x * 2;
	}
	
	// passage par r�f�rence :
	public static void doublerAge(Personne p)
	{
		p.age *= 2;
	}
	
}
