package fr.afcepf.intro.immobilier;

import fr.afcepf.intro.actifs.IActif;

public class BienImmobilier implements IActif {

	private int surface;
	private int prixM2;
	private int nbPieces;
	
	public BienImmobilier(int surface, int prixM2, int nbPieces) 
	{
		this.surface = surface;
		this.prixM2 = prixM2;
		this.nbPieces = nbPieces;
	}

	@Override
	public double getPrix() 
	{		
		return surface * prixM2;
	}

	@Override
	public String toString()
	{
		return nbPieces + " pi�ces - " + surface + "m2 - " + getPrix() + "�";
	}
	
}
