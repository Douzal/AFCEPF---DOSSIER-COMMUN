package fr.afcepf.intro.banque;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

import fr.afcepf.intro.Personne;
import fr.afcepf.intro.banque.exceptions.BankOperationException;

public class PEL extends CompteATerme {

	public final static int DUREE_MIN = 4;
	public final static int DUREE_MAX = 10;
	public final static double PRIME_ETAT = 0.005;
	public final static double TAUX_NOMINAL = 0.015;
	
	private boolean estCloture;
	
	public PEL(String numero, Personne titulaire) 
	{
		super(numero, TAUX_NOMINAL, DUREE_MIN, titulaire);
		estCloture = false;
	}

	@Override
	public void debiter(double montant) throws BankOperationException
	{
		if (estCloture)
		{
			super.debiter(montant);
		}
		else
		{
			throw new BankOperationException("retrait impossible : compte non clotur�", "Retrait PEL", montant);
		}
	}
	
	@Override
	public double calculerMontantInterets()	
	{
		double montantInterets = super.calculerMontantInterets();
		if (this.getAge() >= DUREE_MIN)
		{
			montantInterets *= 1 + PRIME_ETAT;
		}
		return montantInterets;
	}
		
	@Override
	public void crediter(double montant) throws BankOperationException
	{
		if (getAge() <= DUREE_MAX && !this.estCloture)
		{
			super.crediter(montant);
		}
		else
		{
			throw new BankOperationException("credit impossible : delai max atteint ou compte clos", "versement PEL", 0);
		}
	}
		
	public void cloturer() throws BankOperationException
	{
		if (this.getAge() >= DUREE_MIN)
		{
			this.estCloture = true;
		}
		else
		{
			throw new BankOperationException("Cloture impossible : delai minimum non atteint", "Cl�ture PEL", 0);
		}
	}
	
	public double getAge()
	{
		LocalDate dateCourante = LocalDate.now();
		return Period.between(this.getDateCreation(), dateCourante).getYears();
	}
}






