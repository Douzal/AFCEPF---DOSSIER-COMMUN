package fr.afcepf.intro.banque;

import fr.afcepf.intro.Personne;
import fr.afcepf.intro.banque.exceptions.BankOperationException;

public class LivretA extends CompteRemunere 
{
	public final static double TAUX_NOMINAL = 0.0075;
	public final static int PLAFOND = 22950;
	
	public LivretA(String numero, Personne titulaire) 
	{
		super(numero, TAUX_NOMINAL, titulaire);
	}
	
	@Override
	public void crediter(double montant) throws BankOperationException
	{
		if (solde + montant <= PLAFOND)
		{
			super.crediter(montant);
		}
		else
		{
			throw new BankOperationException("D�passement du plafond des d�p�ts", "D�pot Livret A", montant);
		}
	}
	
}
