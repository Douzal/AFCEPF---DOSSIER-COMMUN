package fr.afcepf.intro;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import fr.afcepf.intro.banque.CompteBancaire;

/**
 * Cette classe repr�sente une personne 
 * dans le contexte d'unt tournoi de tennis.
 * Elle a �t� cr��e � des fins p�dagogiques exclusivement.
 * 
 * @version 1.0
 * @author Beno�t
 */
public class Personne
{
	// Attributs :
	
	public final static int AGE_MAJORITE = 18; 
	
	private static int nbInstances = 0;
	
	public int age;
	private String nom;
	private String prenom = "Juste";
	// constante d'instance :
	private final Date dateNaissance;
	private String numeroSecu;
	private int endurance = 3;
	private ArrayList<CompteBancaire> comptes;

	public void ajouterCompte(CompteBancaire c)
	{
		comptes.add(c);
	}
	
	// Constructeurs :
	
	public Personne()
	{
		this.comptes = new ArrayList<>();
		//Calendar c = Calendar.getInstance();
		//c.set(1975,1,1);		
		//this.dateNaissance = c.getTime();
		// date courante :
		this.dateNaissance = new Date();
		nbInstances++;
	}
	
	public Personne(String nom, String prenom)
	{
		// appel au constructeur sans parametre :
		this();
		
		this.nom = nom;
		this.prenom = prenom;
	}
	
	public Personne(String nom, int endurance)
	{
		this();
		this.nom = nom;
		this.endurance = endurance;
		
	}
	
	public Personne(String nom, String prenom, String numeroSecu)
	{
		this(nom, prenom);
		
		this.numeroSecu = numeroSecu;
	}
	
	
	// getters / setters :
	
	public String getNom()
	{
		return nom;
	}
	
	public void setNom(String nom)
	{
		this.nom = nom;
	} 
	
	// M�thodes :

	public String getPrenom()
	{
		return prenom;
	}

	public void setPrenom(String prenom)
	{
		this.prenom = prenom;
	}

	public Date getDateNaissance()
	{
		return dateNaissance;
	}

	public String getNumeroSecu()
	{
		return numeroSecu;
	}

	public void setNumeroSecu(String numeroSecu)
	{
		this.numeroSecu = numeroSecu;
	}

	public int getEndurance()
	{
		return endurance;
	}

	// M�thodes :
	
	public String sePresenter()
	{
		return "Bonjour, je m'appelle " + prenom + " " + nom;
	}

	public void entrainer()
	{
		endurance = endurance + 1;  
	}
	
	public void enregistrer(String path)
	{
		// TODO ecrire dans un fichier
		
	}
	
	public void enregistrer()
	{
		enregistrer("C:\\personne.txt");
	}
	
	
	public static int getNbInstances()
	{
		return nbInstances;
	}
	
	@Override
	public String toString()
	{
		return this.prenom + " " + this.nom.toUpperCase();
	}

}
