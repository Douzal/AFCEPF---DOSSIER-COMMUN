package fr.afcepf.intro.finance;

import fr.afcepf.intro.actifs.IActif;

public class Action implements IActif {

	private String libelle;
	private double prixUnitaire;
	private int quantite;
	
	public Action(String libelle, double prixUnitaire, int quantite) {
		this.libelle = libelle;
		this.prixUnitaire = prixUnitaire;
		this.quantite = quantite;
	}

	@Override
	public double getPrix() {
		return prixUnitaire * quantite;
	}

	@Override
	public String toString()
	{
		return "Action " + libelle + " x " + quantite + " - " + getPrix() + "�";
	}
}
