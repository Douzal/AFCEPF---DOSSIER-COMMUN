package fr.afcepf.intro;

public class Bidon 
{
	// Design pattern SINGLETON
	
	private static Bidon instance;
	
	public static Bidon getInstance()
	{
		if (instance == null)
		{
			instance = new Bidon();
		}
		return instance;
	}
	
	private Bidon()
	{		
	}
	
	public static void FaireQqchose()
	{
		System.out.println("Quelquechose");
	}
	
	public void test()
	{
		System.out.println(this);
	}
}
