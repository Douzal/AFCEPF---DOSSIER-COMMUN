package fr.afcepf.intro.actifs;

import java.util.ArrayList;

import fr.afcepf.intro.banque.CompteATerme;
import fr.afcepf.intro.banque.CompteBancaire;
import fr.afcepf.intro.banque.CompteRemunere;
import fr.afcepf.intro.banque.exceptions.BankOperationException;
import fr.afcepf.intro.finance.Action;
import fr.afcepf.intro.immobilier.BienImmobilier;

public class App {

	public static void main(String[] args) throws BankOperationException {

		ArrayList<IActif> mesActifs = new ArrayList<>();

		//CompteRemunere c1 = new CompteRemunere("22222", 0.2);
		//c1.crediter(1000000);
	
		//CompteATerme c2 = new CompteATerme("333333", 0.2, 5);
		//c2.crediter(1000000);
		
		//mesActifs.add(new CompteBancaire("11111", 1000000));
		//mesActifs.add(c1);
		//mesActifs.add(c2);
		mesActifs.add(new BienImmobilier(280, 8000, 8));
		mesActifs.add(new Action("Pear",1000, 500));
		
		double total = 0;
		for(IActif a : mesActifs)
		{
			total += a.getPrix();
			System.out.println(a.toString() + " prix : " + a.getPrix() + "�");
		}
		System.out.println("TOTAL : " + total + "�");
		
	}
	

}
