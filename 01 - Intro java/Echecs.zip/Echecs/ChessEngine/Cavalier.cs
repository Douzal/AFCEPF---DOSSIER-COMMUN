﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public class Cavalier : Piece
    {
        #region PROPERTIES
        public override string TypePiece
        {
            get { return "Cavalier"; }
        }
        #endregion

        #region CONSTRUCTOR
        public Cavalier(bool couleur) : base(couleur)
        {
            if (couleur)
            {
                this.code = 11;
            }
            else
            {
                this.code = 12;
            }
        }
        #endregion

        #region METHODS
        public override bool Bouger(int xd, int yd, int xa, int ya)
        {
            if ((Math.Abs(xd - xa) > 2) || (Math.Abs(yd - ya) > 2) || (Math.Abs(xd - xa) == 0) || (Math.Abs(yd - ya) == 0))
            {
                return false;
            }

            if ((Math.Abs(xd - xa) == 2) && (Math.Abs(yd - ya) == 2))
            {
                return false;
            }


            if (Math.Abs(xd - xa) == 1)
            {
                if (Math.Abs(yd - ya) != 2)
                {
                    return false;
                }
            }
            if (Math.Abs(yd - ya) == 1)
            {
                if (Math.Abs(xd - xa) != 2)
                {
                    return false;
                }
            }
            //System.out.println("mvt cavalier ok");
            return true;
        }

        public override bool VerifierTrajectoire(Partie p, int xd, int yd, int xa, int ya)
        {
            // verif que pas de piece amie sur la case d'arrivée :
            if (!p.EstVide(xa, ya))
            {
                if (p.echiquier[xa,ya].Couleur == p.echiquier[xd,yd].Couleur)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion
    }
}
