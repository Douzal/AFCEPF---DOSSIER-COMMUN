﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public abstract class Piece
    {
        #region PROPERTIES
        protected bool couleur;

        public bool Couleur
        {
            get { return couleur; }
        }

        protected int code;

        public int Code
        {
            get { return code; }
        }

        private bool aBouge;

        public bool ABouge
        {
            get { return aBouge; }
            set { aBouge = value; }
        }
        #endregion

        #region CONSTRUCTOR
        public Piece(bool couleur)
	    {
		    this.couleur = couleur;
            this.aBouge = false;
	    }
        #endregion

        #region METHODS
        public abstract bool Bouger(int xd, int yd, int xa, int ya);

        public abstract String TypePiece
        {
            get;
        }

        public abstract bool VerifierTrajectoire(Partie p, int xd, int yd, int xa, int ya);
        #endregion
    }
}
