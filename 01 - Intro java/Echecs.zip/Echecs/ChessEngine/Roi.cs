﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public class Roi : Piece
    {
        #region PROPERTIES
        public override string TypePiece
        {
            get { return "Roi";}
        }
        #endregion

        #region CONSTRUCTOR
        public Roi(bool couleur) : base(couleur)
        {
            if (couleur == true)
            {
                this.code = 3;
            }
            else
            {
                this.code = 4;
            }
        }
        #endregion

        #region METHODS
        public override bool Bouger(int xd, int yd, int xa, int ya)
        {
            // mouvement vertical limité à une case :
            if (Math.Abs(yd - ya) > 1)
            {
                return false;
            }

            // mouvement horizontal limité à 1(normal) ou 2(roque) cases :
            if (Math.Abs(xd - xa) > 2)
            {
                return false;
                // !!!mvt de 2 cases autorisé uniquement si roque !
            }

            return true;
        }

        public override bool  VerifierTrajectoire(Partie p, int xd, int yd, int xa, int ya)
        {
            // verif que pas de piece amie sur la case d'arrivée :
            if (!p.EstVide(xa, ya))
            {
                if (p.echiquier[xa,ya].Couleur == p.echiquier[xd,yd].Couleur)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion
    }
}
