﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public class Pion : Piece
    {
        #region PROPERTIES
        public override string TypePiece
        {
            get { return "Pion"; }
        }
        #endregion

        #region CONSTRUCTOR
        public Pion(bool couleur) : base(couleur)
        {
            if (couleur)
            {
                this.code = 1;
            }
            else
            {
                this.code = 2;
            }
        }
        #endregion

        #region METHODS
        public override bool Bouger(int xd, int yd, int xa, int ya)
        {
            //mouvement lateral > 1 case interdit :
            if (Math.Abs(xd - xa) > 1)
            {
                //System.out.println("mvt lateral interdit");
                return false;
            }  // !!!!!!!!!!!!!mvt lateral uniquement si prise (>> à tester en sortie)

            //mouvement de 2 cases permis si position initiale :
            if ((yd == 1) || (yd == 6))
            {
                if (Math.Abs(ya - yd) > 2)
                {
                    //System.out.println("mouvement de plus de 2 cases interdit");
                    return false;
                }
            }
            else
            // mouvement de 1 case sinon :
            {
                if (Math.Abs(ya - yd) > 1)
                {
                    //System.out.println("mouvement de + d'une case interdit");
                    return false;
                }
            }
            // pas de mouvement en arrière :
            if (couleur) //pion blanc :
            {
                if (yd >= ya)
                {
                    //System.out.println("mouvement en arrière interdit");
                    return false;
                }
            }
            else //pion noir :
            {
                if (yd <= ya)
                {
                    //System.out.println("mouvement en arrière interdit");
                    return false;
                }
            }

            return true;
        }


        public override bool  VerifierTrajectoire(Partie p, int xd, int yd, int xa, int ya)
        {
            // verif que pas de piece amie sur la case d'arrivée :
            if (!p.EstVide(xa, ya))
            {
                if (p.echiquier[xa,ya].Couleur == p.echiquier[xd,yd].Couleur)
                {
                    return false;
                }
            }

            //verif de trajectoire du pion :

            // cas de la prise diagonale :
            if ((xd != xa) && (!p.EstVide(xa, ya)))
            {
                return true;
            }

            // pion blanc :
            if (p.echiquier[xd,yd].Couleur == true)
            {
                int i = yd + 1;
                while (i <= ya)
                {
                    if (!p.EstVide(xd, i))
                    {
                        //trajectoire bloquée : pas de prise verticale
                        return false;
                    }
                    i++;
                }
            }
            // pion noir :
            else
            {
                int i = yd - 1;
                while (i >= ya)
                {
                    if (!p.EstVide(xd, i))
                    {
                        return false;
                    }
                    i--;

                }
            }
            return true;
        }
        #endregion

    }
}
