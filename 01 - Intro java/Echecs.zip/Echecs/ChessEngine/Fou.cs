﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public class Fou : Piece
    {
        #region PROPERTIES
        public override string TypePiece
        {
            get { return "Fou"; }
        }
        #endregion

        #region CONSTRUCTORS
        public Fou(bool couleur) : base(couleur)
        {
            if (couleur)
            {
                this.code = 9;
            }
            else
            {
                this.code = 10;
            }
        }
        #endregion

        #region METHODS
        public override bool Bouger(int xd, int yd, int xa, int ya)
        {
            //mouvement diagonal seulement :
            if (Math.Abs(xd - xa) != Math.Abs(yd - ya))
            {
                return false;
            }
            return true;
        }

        public override bool VerifierTrajectoire(Partie p, int xd, int yd, int xa, int ya)
        {
            // verif que pas de piece amie sur la case d'arrivée :
            if (!p.EstVide(xa, ya))
            {
                if (p.echiquier[xa,ya].Couleur == p.echiquier[xd,yd].Couleur)
                {
                    return false;
                }
            }

            if (xd > xa) // gauche
            {
                if (yd < ya) // haut
                {
                    int i = 1;
                    while (i < Math.Abs(xd - xa))
                    {
                        if (p.EstVide(xd - i, yd + i) == false)
                        {
                            return false;
                        }
                        i++;
                    }
                }
                else // bas
                {
                    int i = 1;
                    while (i < Math.Abs(xd - xa))
                    {
                        if (p.EstVide(xd - i, yd - i) == false)
                        {
                            return false;
                        }
                        i++;
                    }
                }
            }
            else // droite
            {
                if (yd < ya) // haut
                {
                    int i = 1;
                    while (i < Math.Abs(xd - xa))
                    {
                        if (p.EstVide(xd + i, yd + i) == false)
                        {
                            return false;
                        }
                        i++;
                    }
                }
                else // bas
                {
                    int i = 1;
                    while (i < Math.Abs(xd - xa))
                    {
                        if (p.EstVide(xd + i, yd - i) == false)
                        {
                            return false;
                        }
                        i++;
                    }
                }
            }
            return true;
        }
        #endregion
    }
}
