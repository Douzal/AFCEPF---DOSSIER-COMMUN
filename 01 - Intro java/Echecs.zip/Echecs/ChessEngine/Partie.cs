﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public enum EtatPartie
    {
        Debut,
        EnCours,
        Terminee
    }

    public class Partie
    {
        #region PROPERTIES

        private EtatPartie etat;

        public EtatPartie Etat
        {
            get { return etat; }
        }

        public Piece[,] echiquier = new Piece[8, 8];
        
        private int turn;  //tour de jeu (compteur)
        
        private bool main; 

        public bool Main
        {
            get { return main; }
        }
        
        private Message message = new Message();

        public string Message
        {
            get { return message.mvt + " - " + message.msg; }
        }

        public string ToString()
        {
            return message.EchToString();
        }

        #endregion

        #region CONSTRUCTOR
        public Partie()
        {
            etat = EtatPartie.Debut;
            turn = 1;
            main = true; //main aux blancs
            //System.out.println("initialisation de l'echiquier");
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    echiquier[i, j] = null;
                }
            }
            // DECLARATION DES PIECES :
            // -----------------------
            //pieces blanches :
            echiquier[0, 0] = new Tour(true);
            echiquier[1, 0] = new Cavalier(true);
            echiquier[2, 0] = new Fou(true);
            echiquier[3, 0] = new Dame(true);
            echiquier[4, 0] = new Roi(true);
            echiquier[5, 0] = new Fou(true);
            echiquier[6, 0] = new Cavalier(true);
            echiquier[7, 0] = new Tour(true);

            echiquier[0, 1] = new Pion(true);
            echiquier[1, 1] = new Pion(true);
            echiquier[2, 1] = new Pion(true);
            echiquier[3, 1] = new Pion(true);
            echiquier[4, 1] = new Pion(true);
            echiquier[5, 1] = new Pion(true);
            echiquier[6, 1] = new Pion(true);
            echiquier[7, 1] = new Pion(true);

            //pieces noires :
            echiquier[0, 7] = new Tour(false);
            echiquier[1, 7] = new Cavalier(false);
            echiquier[2, 7] = new Fou(false);
            echiquier[3, 7] = new Dame(false);
            echiquier[4, 7] = new Roi(false);
            echiquier[5, 7] = new Fou(false);
            echiquier[6, 7] = new Cavalier(false);
            echiquier[7, 7] = new Tour(false);

            echiquier[0, 6] = new Pion(false);
            echiquier[1, 6] = new Pion(false);
            echiquier[2, 6] = new Pion(false);
            echiquier[3, 6] = new Pion(false);
            echiquier[4, 6] = new Pion(false);
            echiquier[5, 6] = new Pion(false);
            echiquier[6, 6] = new Pion(false);
            echiquier[7, 6] = new Pion(false);

            UpdateMessage("debut");
        }
        #endregion

        #region METHODS
        public bool EstVide(int x, int y)
        {
            return this.echiquier[x, y] == null;
        }

        public void Placer(int xd, int yd, int xa, int ya)
        {
            echiquier[xa, ya] = echiquier[xd, yd];
            echiquier[xd, yd] = null;
        }

        public int XRoi(bool couleur)
        {
            for (int i = 0; i <= 7; i++)
            {
                for (int j = 0; j <= 7; j++)
                {
                    if (!EstVide(i, j))
                    {
                        if (echiquier[i, j].TypePiece == "Roi")
                        {
                            if (echiquier[i, j].Couleur == couleur)
                            {
                                return i;
                            }
                        }
                    }
                }
            }
            return -1;
        }

        public int YRoi(bool couleur)
        {
            for (int i = 0; i <= 7; i++)
            {
                for (int j = 0; j <= 7; j++)
                {
                    if (!EstVide(i, j))
                    {
                        if (echiquier[i, j].TypePiece == "Roi")
                        {
                            if (echiquier[i, j].Couleur == couleur)
                            {
                                return j;
                            }
                        }
                    }
                }
            }
            return -1;
        }

        public bool Autoriser(int xd, int yd, int xa, int ya)
        {

            // 1 ) VERIF QUE CASE DE DEPART NON VIDE :
            // ***************************************
            //System.out.println("verif que case de depart non vide :");
            if (echiquier[xd, yd] == null)
            {
                //System.out.println("case de départ vide");
                message.msg = "Coup interdit : case de départ vide";
                return false;
            }

            // 2 ) VERIF QUE CASE DEPART != CASE ARRIVEE :
            // *******************************************
            if ((xd == xa) && (yd == ya))
            {
                //System.out.println("case départ = case arrivée");
                message.msg = "Coup interdit : case départ = case arrivée";
                return false;
            }

            // 3 ) VERIF QUE LA PIECE APPARTIENT AU JOUEUR EN COURS (COULEUR) :
            // ****************************************************************
            //System.out.println("verif que la piece appartient au joueur en cours :");
            if (echiquier[xd, yd].Couleur != main)
            {
                message.msg = "Coup interdit : piece adverse";
                return false;
            }

            // 4 ) VERIF QUE MOUVEMENT AUTORISE (Piece.bouger()) :
            // ***************************************************
            if (echiquier[xd, yd].Bouger(xd, yd, xa, ya) == false)
            {
                //System.out.println("déplacement interdit par les regles de mvt");
                message.msg = "Coup interdit : déplacement interdit par les regles de mvt";
                return false;
            }

            // 5 ) VERIF QUE TRAJECTOIRE LIBRE :
            // *********************************
            if (echiquier[xd, yd].VerifierTrajectoire(this, xd, yd, xa, ya) == false)
            {
                //System.out.println("trajectoire bloquée");
                message.msg = "Coup interdit : trajectoire bloquée";
                return false;
            }

            // 6 ) VERIF QUE PAS DE PIECE AMIE SUR CASE ARRIVEE :
            // **************************************************
            if ((echiquier[xa, ya] != null) && (echiquier[xd, yd].Couleur == echiquier[xa, ya].Couleur))
            {
                //System.out.println("piece amie sur case arrivee");
                message.msg = "Coup interdit : piece amie sur case arrivee";
                return false;
            }

            // 5 ) cas particulier pour la prise par le pion :
            // (resolution du problème de la prise en passant en même temps ?)

            if (echiquier[xd, yd].TypePiece == "Pion")
            {
                if ((xd != xa) && (Math.Abs(yd - ya) == 2))
                {
                    message.msg = "Coup interdit : mouvement interdit";
                    return false;
                }
                if ((xd == xa) && (EstVide(xa, ya) == false))
                {
                    message.msg = "Coup interdit : mouvement interdit";
                    return false;
                }
                if ((xd != xa) && (EstVide(xa, ya) == true))
                {
                    message.msg = "Coup interdit : mouvement interdit";
                    return false;
                }
            }
            return true;
        }

        public bool Action(int xd, int yd, int xa, int ya)
        {
            if (this.etat == EtatPartie.Terminee)
            {
                return false;
            }

            if ((xd > 7) || (yd > 7) || (xa > 7) || (ya > 7))
            {
                return false;
            }

            message.mvt = "" + (char)(97 + xd) + (yd + 1) + " - " + (char)(97 + xa) + (ya + 1);
            if (!Autoriser(xd, yd, xa, ya))
            {
                return false;
            }

            // 5 ) VERIF QUE JOUEUR EN COURS PAS ECHEC APRES MOUVEMENT :
            // *******************************************************
            Piece buff = echiquier[xa, ya];
            Placer(xd, yd, xa, ya);
            main = !main;
            if (Echec(XRoi(!main), YRoi(!main)))
            {
                Placer(xa, ya, xd, yd);
                echiquier[xa, ya] = buff;
                main = !main;
                UpdateMessage("mouvement impossible : roi du joueur en cours en échec");
                return false;
            }
            else
            {
                Placer(xa, ya, xd, yd);
                echiquier[xa, ya] = buff;
                main = !main;
            }
            // 6 ) divers :
            // ****************************************************

            //promotion :
            if (echiquier[xd, yd].TypePiece == "Pion")
            {
                if ((ya == 0) || (ya == 7))
                {
                    echiquier[xd, yd] = new Dame(main);
                }
            }


            //Roque :
            if ((echiquier[xd, yd].TypePiece == "Roi") && (Math.Abs(xa - xd) == 2))
            {
                if (yd != ya) return false;
                // verif 1er mvt roi :
                if (echiquier[xd, yd].ABouge == true)
                {
                    message.msg = "Roque interdit";
                    return false;
                }
                //petit roque :
                if (xa > xd)
                {
                    //verif 1er mvt tour :
                    if (echiquier[7, yd].ABouge == true)
                    {
                        message.msg = "Roque interdit";
                        return false;
                    }
                    // verif cases du parcours pas en echec :
                    main = !main;
                    for (int r = xd; r <= 6; r++)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            for (int j = 0; j < 8; j++)
                            {
                                if (Autoriser(i, j, r, yd))
                                {
                                    //roque interdit :
                                    main = !main;
                                    message.msg = "Roque interdit";
                                    return false;
                                }
                            }
                        }
                    }
                    main = !main;
                    //déplacement de la tour :
                    Placer(7, yd, 5, yd);
                }
                //grand roque :
                else
                {
                    if (xd > xa)
                    {
                        // verif 1er mvt tour :
                        if (echiquier[0, yd].ABouge == true)
                        {
                            message.msg = "Roque interdit";
                            return false;
                        }
                        // verif cases du parcours pas en echec :
                        main = !main;
                        for (int r = xd; r >= 1; r--)
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                for (int j = 0; j < 8; j++)
                                {
                                    if (Autoriser(i, j, r, yd))
                                    {
                                        //roque interdit :
                                        main = !main;
                                        message.msg = "Roque interdit";
                                        return false;
                                    }
                                }
                            }
                        }
                        main = !main;
                        //déplacement de la tour :
                        Placer(0, yd, 3, yd);
                    }
                    else
                    {
                        message.msg = "Roque interdit";
                        return false;
                    }
                }
            }

            //COUP AUTORISE :
            //déplacement effectif :
            Placer(xd, yd, xa, ya);
            echiquier[xa, ya].ABouge = true;
            turn++;

            if (Echec(XRoi(!main), YRoi(!main)))
            {
                if (EstMat(!main) == true)
                {
                    UpdateMessage("*** ECHEC ET MAT !!! ***");
                    return true;
                }
                else
                {
                    UpdateMessage("* Echec au Roi *");
                    main = !main;
                    return true;
                }
            }

            main = !main;

            if (main)
            {
                UpdateMessage("main aux blancs");
            }
            else
            {
                UpdateMessage("main aux noirs");
            }


            return true;
        }

        public bool Echec(int x, int y)
        {
            for (int i = 0; i <= 7; i++)
            {
                for (int j = 0; j <= 7; j++)
                {
                    if (Autoriser(i, j, x, y) == true)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void UpdateMessage(String msg)
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (echiquier[i,j] == null)
                    {
                        message.echiquier[j,i] = 0;
                    }
                    else
                    {
                        message.echiquier[j,i] = echiquier[i,j].Code;
                    }
                }
            }
            message.msg = msg;
        }

        public bool EstMat(bool couleur)
        {

            int xa = XRoi(couleur);
            int ya = YRoi(couleur);

            main = !main;

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    for (int i2 = 0; i2 < 8; i2++)
                    {
                        for (int j2 = 0; j2 < 8; j2++)
                        {
                            Piece buff = echiquier[i2, j2];
                            if (Action(i, j, i2, j2))
                            {
                                //Piece buff = echiquier[i2, j2];
                                //Placer(i, j, i2, j2);
                                //main = !main;
                                if (!Echec(XRoi(couleur), YRoi(couleur)))
                                {
                                    Placer(i2, j2, i, j);
                                    echiquier[i2, j2] = buff;
                                    return false;
                                }
                                else
                                {
                                    Placer(i2, j2, i, j);
                                    echiquier[i2, j2] = buff;
                                    main = !main;
                                }
                            }
                        }
                    }
                }
            }
            this.etat = EtatPartie.Terminee;
            return true;
        }
        #endregion

    }
}
