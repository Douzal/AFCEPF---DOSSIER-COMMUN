﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChessEngine
{
    public class Message
    {
        public int[,] echiquier = new int[8, 8];//contient les codes des pieces
        public String mvt; // ex : e4 - e5
        public String msg; // ex : "fou prend tour"

        public String EchToString()
        {
            String ligne = "";
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    ligne = ligne + echiquier[i, j].ToString() + "-";
                }
            }
            return ligne.Substring(0, ligne.Length -1);
        }
    }
}
