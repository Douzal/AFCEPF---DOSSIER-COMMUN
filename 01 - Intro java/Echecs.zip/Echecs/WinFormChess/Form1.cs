﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ChessEngine;
using WinFormChess.Controls;

namespace WinFormChess
{
    public partial class Form1 : Form
    {
        int tailleCase = 40;
        Partie partie;

        int xd = -1;
        int yd = -1;
        int xa = -1;
        int ya = -1;

        public Form1()
        {
            InitializeComponent();

            board.Width = Math.Min(boardContainer.Width, boardContainer.Height);
            board.Height = Math.Min(boardContainer.Width, boardContainer.Height);
            tailleCase = board.Width / 8;

            prisesBlanches.BackgroundImage = global::WinFormChess.Properties.Resources.boisn;
            prisesNoires.BackgroundImage = global::WinFormChess.Properties.Resources.boisn;
            txtMessages.AppendText("WELCOME TO CHESSCRAFT :)\n");

            board.AllowDrop = true;
            this.GiveFeedback +=new GiveFeedbackEventHandler(board_GiveFeedback);

            DrawBoard();
            partie = new Partie();
            DrawPieces();
        }

        #region METHODS

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000;  // Turn on WS_EX_COMPOSITED
                return cp;
            }
        }

        private void DrawPieces()
        {
            if (partie == null)
            {

                return;
            }
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Piece piece = partie.echiquier[i, j];
                    if (piece != null)
                    {
                        TransparentControl p = new TransparentControl();
                        p.Margin = new System.Windows.Forms.Padding(0);
                        p.Padding = new System.Windows.Forms.Padding(0);

                        p.Size = new System.Drawing.Size(tailleCase, tailleCase);
                        p.Image = getImgPiece(piece);
                        p.Location = new Point(i * tailleCase, j * tailleCase);
                       
                        p.MouseDown += new MouseEventHandler(piece_MouseDown);
                        
                        board.Controls.Add(p);
                        p.BringToFront();
                    }
                }
            }
        }

        private void MiseAJourPrises()
        {
            // on recupere la piece de destination :
            foreach (Control c in board.Controls)
            {
                if (c is TransparentControl)
                {
                    if (c.Location.X / tailleCase == xa && c.Location.Y / tailleCase == ya)
                    {
                        FlowLayoutPanel prises = null;
                        if (partie.Main)
                        {
                            prises = prisesNoires;
                        }
                        else
                        {
                            prises = prisesBlanches;
                        }
                        prises.Controls.Add(c);
                    }
                }
            }
        }

        private void DrawBoard()
        {

            bool couleur = true;
            int x = 0;
            int y = 0;

            board.Size = new Size(tailleCase * 8, tailleCase * 8);

            for (int i = 0; i < 8; i++)
            {
                x = 0;
                for (int j = 0; j < 8; j++)
                {
                    PictureBox p = new PictureBox();
                    p.Margin = new System.Windows.Forms.Padding(0);
                    p.Padding = new System.Windows.Forms.Padding(0);

                    p.Size = new System.Drawing.Size(tailleCase, tailleCase);
                    p.SizeMode = PictureBoxSizeMode.StretchImage;
                    p.Image = getImgCase(couleur);
                    p.Location = new Point(x, y);

                    board.Controls.Add(p);
                    couleur = !couleur;
                    x += tailleCase;
                }
                couleur = !couleur;
                y += tailleCase;
            }
        }

        private System.Drawing.Image getImgPiece(Piece p)
        {
            switch (p.Code)
            {
                case 1:
                    return global::WinFormChess.Properties.Resources.PION_B;
                case 2:
                    return global::WinFormChess.Properties.Resources.PION_N;
                case 3:
                    return global::WinFormChess.Properties.Resources.ROI_B;
                case 4:
                    return global::WinFormChess.Properties.Resources.ROI_N;
                case 5:
                    return global::WinFormChess.Properties.Resources.REINE_B;
                case 6:
                    return global::WinFormChess.Properties.Resources.REINE_N;
                case 7:
                    return global::WinFormChess.Properties.Resources.TOUR_B;
                case 8:
                    return global::WinFormChess.Properties.Resources.TOUR_N;
                case 9:
                    return global::WinFormChess.Properties.Resources.FOU_B;
                case 10:
                    return global::WinFormChess.Properties.Resources.FOU_N;
                case 11:
                    return global::WinFormChess.Properties.Resources.CAVA_B;
                case 12:
                    return global::WinFormChess.Properties.Resources.CAVA_N;
                default:
                    return null;
            }
        }

        private System.Drawing.Image getImgCase(bool couleur)
        {
            if (couleur)
            {
                return global::WinFormChess.Properties.Resources.boisb;
            }
            else
            {
                return global::WinFormChess.Properties.Resources.boisn;
            }
        }
        #endregion

        #region EVENTS

        private TransparentControl pieceEnMouvement = null;

        void piece_MouseDown(object sender, MouseEventArgs e)
        {
            pieceEnMouvement = (TransparentControl)sender;

            xd = pieceEnMouvement.Location.X / tailleCase;
            yd = pieceEnMouvement.Location.Y / tailleCase;

            pieceEnMouvement.Visible = false;

            DoDragDrop(sender as TransparentControl, DragDropEffects.Move);
            pieceEnMouvement.Visible = true;
        }
        
        private void board_DragEnter(object sender, DragEventArgs e)
        {
            if ((e.AllowedEffect & DragDropEffects.Move) != 0
                && e.Data.GetDataPresent(typeof(TransparentControl)))
            {
                e.Effect = DragDropEffects.Move;
            }
        }

        private void board_DragDrop(object sender, DragEventArgs e)
        {
            
            Point pt = board.PointToClient(new Point(e.X, e.Y));

            xa = (pt.X / tailleCase);
            ya = (pt.Y / tailleCase);

            if (partie.Action(xd, yd, xa, ya))
            {
                MiseAJourPrises();
                board.Controls.Clear();
                DrawBoard();
                DrawPieces();
                txtMessages.AppendText(partie.Message + "\n");
            }
            xd = -1;
            yd = -1;
            xa = -1;
            ya = -1;
        }

        // Image de la piece sur curseur de drag & drop :
        private void board_GiveFeedback(Object sender, GiveFeedbackEventArgs e)
        {
            if (e.Effect == DragDropEffects.Move)
            {
                e.UseDefaultCursors = false;
                Cursor.Current = new Cursor(((Bitmap)(pieceEnMouvement.Image)).GetHicon());
            }
        }

        #endregion

        private void nouvelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            board.Controls.Clear();
            prisesBlanches.Controls.Clear();
            prisesNoires.Controls.Clear();
            DrawBoard();
            partie = new Partie();
            DrawPieces();
            txtMessages.Clear();
            txtMessages.AppendText("Nouvelle Partie\n");
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            board.Width = Math.Min(boardContainer.Width, boardContainer.Height);
            board.Height = Math.Min(boardContainer.Width, boardContainer.Height);
            
            int vPadding = (boardContainer.Height - board.Height) / 2;
            int hPadding = (boardContainer.Width - board.Width) / 2;

            boardContainer.Padding = new System.Windows.Forms.Padding(hPadding, vPadding, hPadding, vPadding);
            

            tailleCase = board.Width / 8;
            board.Controls.Clear();
            DrawBoard();
            DrawPieces();
        }


    }
}
