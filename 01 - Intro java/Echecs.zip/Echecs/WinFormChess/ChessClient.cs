﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using CE = ChessEngine;

namespace WinFormChess
{
    [ServiceContract(CallbackContract = typeof(IChessService))]
    public interface IChessService
    {
        [OperationContract()]
        void Play(int xd, int yd, int xa, int ya);
    }

    public interface IChessChannel : IChessService, IClientChannel
    {
    }

    public class ChessClient : IChessService 
    {
        private IChessChannel channel;

        private DuplexChannelFactory<IChessChannel> factory;

        public delegate void UserPlay(int xd, int yd, int xa, int ya);

        public static event UserPlay UserPlayed;

        public void Connect()
        {
            UserPlayed += new UserPlay(ChessClient_UserPlayed);

            InstanceContext context = new InstanceContext(new ChessClient());
            factory = new DuplexChannelFactory<IChessChannel>(context, "ChessEndPoint");

            channel = factory.CreateChannel();
            channel.Open();

        }

        void ChessClient_UserPlayed(int xd, int yd, int xa, int ya)
        {
            // TODO : maj echiquier
        }

        public void Play(int xd, int yd, int xa, int ya)
        {
            UserPlayed(xd, yd, xa, ya);
        }

        public void Disconnect()
        {
            if (channel != null)
            {
                channel.Close();
            }
            if (factory != null)
            {
                factory.Close();
            }
        }

        public void DoPlay(int xd, int yd, int xa, int ya)
        {
            channel.Play(xd, yd, xa, ya);
        }
    }
}
