﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.PeerResolvers;

namespace WinFormChess
{
    public class ChessServer
    {
        private CustomPeerResolverService cprs;
        private ServiceHost host;

        public void Start()
        {
            cprs = new CustomPeerResolverService();
            cprs.RefreshInterval = TimeSpan.FromSeconds(5);
            host = new ServiceHost(cprs);
            cprs.ControlShape = true;
            cprs.Open();
            host.Open(TimeSpan.FromDays(1000000));
        }

        public void Stop()
        {
            cprs.Close();
            host.Close();
        }
    }
}
