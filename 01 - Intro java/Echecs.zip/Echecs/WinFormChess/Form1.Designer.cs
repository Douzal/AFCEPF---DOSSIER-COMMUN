﻿namespace WinFormChess
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.board = new System.Windows.Forms.Panel();
            this.txtMessages = new System.Windows.Forms.TextBox();
            this.prisesBlanches = new System.Windows.Forms.FlowLayoutPanel();
            this.prisesNoires = new System.Windows.Forms.FlowLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.partieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nouvelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitre = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.boardContainer = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.boardContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // board
            // 
            this.board.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.board.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.board.Location = new System.Drawing.Point(0, 0);
            this.board.Name = "board";
            this.board.Size = new System.Drawing.Size(362, 360);
            this.board.TabIndex = 0;
            this.board.DragDrop += new System.Windows.Forms.DragEventHandler(this.board_DragDrop);
            this.board.DragEnter += new System.Windows.Forms.DragEventHandler(this.board_DragEnter);
            // 
            // txtMessages
            // 
            this.txtMessages.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtMessages.Location = new System.Drawing.Point(0, 437);
            this.txtMessages.Multiline = true;
            this.txtMessages.Name = "txtMessages";
            this.txtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMessages.Size = new System.Drawing.Size(552, 76);
            this.txtMessages.TabIndex = 1;
            // 
            // prisesBlanches
            // 
            this.prisesBlanches.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.prisesBlanches.Dock = System.Windows.Forms.DockStyle.Left;
            this.prisesBlanches.Location = new System.Drawing.Point(0, 0);
            this.prisesBlanches.Name = "prisesBlanches";
            this.prisesBlanches.Size = new System.Drawing.Size(99, 360);
            this.prisesBlanches.TabIndex = 2;
            // 
            // prisesNoires
            // 
            this.prisesNoires.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.prisesNoires.Dock = System.Windows.Forms.DockStyle.Right;
            this.prisesNoires.Location = new System.Drawing.Point(461, 0);
            this.prisesNoires.Name = "prisesNoires";
            this.prisesNoires.Size = new System.Drawing.Size(91, 360);
            this.prisesNoires.TabIndex = 3;
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.partieToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(552, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // partieToolStripMenuItem
            // 
            this.partieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nouvelleToolStripMenuItem});
            this.partieToolStripMenuItem.Name = "partieToolStripMenuItem";
            this.partieToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.partieToolStripMenuItem.Text = "Partie";
            // 
            // nouvelleToolStripMenuItem
            // 
            this.nouvelleToolStripMenuItem.Name = "nouvelleToolStripMenuItem";
            this.nouvelleToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
            this.nouvelleToolStripMenuItem.Text = "Nouvelle";
            this.nouvelleToolStripMenuItem.Click += new System.EventHandler(this.nouvelleToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblTitre);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(552, 49);
            this.panel1.TabIndex = 6;
            // 
            // lblTitre
            // 
            this.lblTitre.AutoSize = true;
            this.lblTitre.Font = new System.Drawing.Font("Neuropol", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitre.Location = new System.Drawing.Point(160, 0);
            this.lblTitre.Name = "lblTitre";
            this.lblTitre.Size = new System.Drawing.Size(246, 30);
            this.lblTitre.TabIndex = 6;
            this.lblTitre.Text = "Chess Craft 1.0";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.boardContainer);
            this.panel2.Controls.Add(this.prisesBlanches);
            this.panel2.Controls.Add(this.prisesNoires);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(552, 360);
            this.panel2.TabIndex = 7;
            // 
            // boardContainer
            // 
            this.boardContainer.Controls.Add(this.board);
            this.boardContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.boardContainer.Location = new System.Drawing.Point(99, 0);
            this.boardContainer.Name = "boardContainer";
            this.boardContainer.Size = new System.Drawing.Size(362, 360);
            this.boardContainer.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 513);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtMessages);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "ChessCraft";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.boardContainer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel board;
        private System.Windows.Forms.TextBox txtMessages;
        private System.Windows.Forms.FlowLayoutPanel prisesBlanches;
        private System.Windows.Forms.FlowLayoutPanel prisesNoires;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem partieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nouvelleToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTitre;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel boardContainer;


    }
}

